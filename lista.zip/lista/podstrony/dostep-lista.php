<?php 

$server = 'poligon.zsp2.krotoszyn.net';
$user = '4f_nowak_da';
$pass = 'zaq123';
$db = '4f_nowak_da_lista';
$port = '33060';
$mysqli = new mysqli($server, $user, $pass, $db, $port); 
